﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WordCount
{
    public partial class Form1 : Form
    {
        string sentence;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           /* string sentence; string[] word; double count = 1; int l = 0;
            sentence = Convert.ToString(textBox1.Text);
            // Convert.ToString(textBox2.Text);

            while (l <= sentence.Length - 1)
            {
                if (sentence[l] == ' ' || sentence[l] == '\n' || sentence[l] == '\t')
                {
                    count++;
                }
                l++;
            }
            textBox3.Text = count.ToString();
            word = (sentence.Split(' '));
            // find how to print out and equate it to word
            textBox2.Text = Convert.ToString(word);*/

            int i = 0;
            char[] delimiters = { ' ', ',', ';', '?', '.', '!' };
            string[] each_word = textBox1.Text.Split(delimiters);
            listBox1.Items.Clear();
            foreach (string item in each_word)
            {
                if (item.Length > 0)
                {
                    listBox1.Items.Add(item);
                    i = i + 1;
                }
            }
            textBox3.Text = i.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}


//foreach (string word in sentence.Split())
//textBox2.Text = sentence.Split();
//textBox2.Text = (word in sentence.Split());
// Convert.ToChar(sentence);
// string[] variable = sentence.Split(' ');

/*   public static string printWords(String s)*/
/* {  
 * 
 * int i = 0;
 Char[] mychar = { ' ', ',', ';', '?'};
 string[] word = textBox1.Text.Split(mychar);
 listBox1.Items.Clear();
 foreach(string item in word)
 {
     if (item.Length > 0)
     {
         listBox1.Items.Add(item);
         i = i + 1;
     }
 }
 textBox2.Text = i.ToString();
 * 
     foreach (String val in s.Split(' ')) 
         Console.WriteLine(val);
 }

 static public void Main()
 {
     string sentence = Convert.ToString(textBox1.Text);
     textBox3.Text = printWords(sentence);
 }



 // foreach (string word in sentence.Split( ))
 //   Console.WriteLine(word);
 /*
 public static void printWords(String s) 
{      
foreach(String val in s.Split(" "))  
 Console.WriteLine(val);  
}  
static public void Main ()  
{  
String Str = "sky is blue"; 
printWords(Str); 
}
}
}*/
